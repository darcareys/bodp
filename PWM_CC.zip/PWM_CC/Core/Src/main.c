/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include  <string.h>
#include <stdlib.h>
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* 帧结构定义（固定5字节�? */
#define FRAME_HEADER1 0xEB        // 帧头�?1字节
#define FRAME_HEADER2 0x90        // 帧头�?2字节
#define FRAME_LENGTH 41            // 正确帧固定长度：5+36 
#define CONTROL_LOW_INDEX 2       // 控制低字节索引（�?3字节�?
#define CHECKSUM_INDEX 40          // 校验和索引（�?35字节，最�?1字节�?
#define PWM_LENGTH 36             // 存放pwm值 
/* 全局变量 */
uint8_t rx_buffer[FRAME_LENGTH];  // 接收缓冲区（41字节�?
uint8_t rx_count = 0;             // 已接收字节数�?0~4�?
uint16_t pwm_value_buffer[PWM_LENGTH];
/* USER CODE END 0 */
#define  SERVO_ALL_OFF 0
#define  SERVO1_UP 1
#define  SERVO2_UP 2
#define  SERVO3_UP 3
#define  SERVO4_UP 4
#define  SERVO5_UP 5 
#define  SERVO6_UP 6
#define  SERVOA_ALL_UP 7

#define  PWM_HIGH 2000
#define  PWM_MEDIAN 1300
#define  PWM_LOW 900
//舵机弿合默认忿
#define  PWM_ON 1950  // 1950
#define  PWM_DOWN 1050   //1050 
#define  INTERVAL_TIME 3000

static uint32_t cnt_up,cnt_down;//记录高占空比和低占空比持续时闿
static uint8_t state ,pwm_high,pwm_low; //记录承有舵机状怿
static uint8_t servo_state,pwm_state; //接收高低占空毿
static uint32_t cc1,cc2,dutycnt,record_time;
/**
  * @brief  The application entry point.
  * @retval int
  */
void pwm_init(void){
			HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_1);
			HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
			HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
			HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
			HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
			HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
//	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1,PWM_ON);
//	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2,PWM_ON);
//	__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3,PWM_ON);
//	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1,PWM_ON);
//	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2,PWM_ON);
//	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3,PWM_ON);
	
}  
 
 static uint32_t GetPwmVlaue(void){
	
		__HAL_TIM_CLEAR_FLAG(&htim1,TIM_CHANNEL_1);
		HAL_TIM_IC_Start(&htim1,TIM_CHANNEL_1);
		HAL_TIM_IC_Start(&htim1,TIM_CHANNEL_2);
			while(__HAL_TIM_GET_FLAG(&htim1,TIM_CHANNEL_1)==0){};
				__HAL_TIM_CLEAR_FLAG(&htim1,TIM_CHANNEL_1);
			while(__HAL_TIM_GET_FLAG(&htim1,TIM_CHANNEL_2)==0){};	
			while(__HAL_TIM_GET_FLAG(&htim1,TIM_CHANNEL_1)==0){};
				cc1=__HAL_TIM_GET_COMPARE(&htim1,TIM_CHANNEL_1);
			while(__HAL_TIM_GET_FLAG(&htim1,TIM_CHANNEL_2)==0){};
				cc2=__HAL_TIM_GET_COMPARE(&htim1,TIM_CHANNEL_2);
			if(cc2<cc1){
				return(0xFFFFFFFF-cc1+cc2);
			}
		HAL_TIM_IC_Stop(&htim1,TIM_CHANNEL_1);
	    HAL_TIM_IC_Stop(&htim1,TIM_CHANNEL_2);
					
		return cc2-cc1;
} 
 
uint8_t GetPwmState(void){
	if(PWM_MEDIAN<dutycnt && dutycnt < PWM_HIGH){
		return state=2;//高占空比
	}
	if(PWM_LOW<dutycnt && dutycnt < PWM_MEDIAN){
		return state=1;//低占空比
	}
	else 
	{
		return state=0;
	}
}
  
  
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_USART3_UART_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
 // pwm_init();通过获取串口接收数据进行判断 
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
 while (1)
  {
    /* USER CODE END WHILE */
/* USER CODE END WHILE */
	dutycnt=GetPwmVlaue();
	pwm_state=GetPwmState();//0,1,2 分别代表未开启 ,低占空比,高占空比 开始必须在高位 
	switch (servo_state){
		case SERVO_ALL_OFF : if(pwm_state==2){
			
					__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1,PWM_MEDIAN);
					servo_state = SERVO1_UP;};
//					record_time= HAL_GetTick();
					break;
		case SERVO1_UP : if(pwm_state==1){
					
					__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2,PWM_MEDIAN);
					servo_state = SERVO2_UP;};
					
					break;
		case SERVO2_UP:if(pwm_state==2){
					
					__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3,PWM_MEDIAN);
					servo_state = SERVO3_UP;};
//					if((HAL_GetTick()-record_time)<INTERVAL_TIME){//如果一个周期时间低于INTERVAL_TIME 全部掉
//						__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4,PWM_ON);
//						__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1,PWM_ON);
//						__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2,PWM_ON);
//						__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3,PWM_ON);
//						servo_state = SERVO_ALL_OFF;
//					}
//					record_time=HAL_GetTick(); 
					break;
		case SERVO3_UP:if(pwm_state==1){
					
					__HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_4,PWM_MEDIAN);
					servo_state = SERVO4_UP;};
					break;
		case SERVO4_UP:if(pwm_state==2){
					
					__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1,PWM_MEDIAN);
					servo_state = SERVO5_UP;};
//						if((HAL_GetTick()-record_time)<INTERVAL_TIME){
//						__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2,PWM_ON);
//						__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3,PWM_ON);
//						__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4,PWM_ON);
//						servo_state = SERVO_ALL_OFF;
//					}
//					record_time=HAL_GetTick();
					break;
		case SERVO5_UP:if(pwm_state==1){
					
					__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2,PWM_MEDIAN);
					servo_state = SERVO6_UP;};
					break;
		case SERVO6_UP:if(pwm_state==2){
					__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3,PWM_MEDIAN);
					servo_state = SERVO_ALL_OFF;	
					pwm_init();break;
						};

		}

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}
  /* USER CODE END 3 */


/**
  * @brief System Clock Configuration
  * @retval None
  */
  /* USER CODE END 3 */


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 7;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim1, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
  sConfigIC.ICSelection = TIM_ICSELECTION_INDIRECTTI;
  if (HAL_TIM_IC_ConfigChannel(&htim1, &sConfigIC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  if (HAL_TIM_IC_ConfigChannel(&htim1, &sConfigIC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
  sConfigIC.ICSelection = TIM_ICSELECTION_INDIRECTTI;
  if (HAL_TIM_IC_ConfigChannel(&htim1, &sConfigIC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 19999;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 7;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 19999;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */
 HAL_UART_Receive_IT(&huart3, &rx_buffer[rx_count], 1);
  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
  // 2. 校验和校验（�?4字节�? vs �?5字节�?
  // 1. 帧头校验（必须为EB 90）void process_control_bits(void)
void reset_receive(void)
{
  memset(rx_buffer, 0, FRAME_LENGTH);  // 清空缓冲�?
  rx_count = 0;                        // 重置接收计数
  HAL_UART_Receive_IT(&huart3, &rx_buffer[rx_count], 1);  // 重启接收
}



uint8_t calculate_checksum(void)
{
  uint8_t sum = 0;
  for (uint8_t i = 0; i <(FRAME_LENGTH-1); i++)  // 仅计算前40字节
  {
    sum += rx_buffer[i];
  }
  return sum;  // 自动取低8位（溢出自动截断�?
}
uint16_t switch_low_pwm(uint8_t n){
		for(uint8_t i=0;i<9;i++){
			//小端转换
        	pwm_value_buffer[i]=(rx_buffer[4*i+5]<<8)|rx_buffer[4*i+4];
				if(pwm_value_buffer[i]>1500){
				pwm_value_buffer[i]=1500;
			}
			if(pwm_value_buffer[i]<900){
				pwm_value_buffer[i]=900;
			}
		}
				
		return pwm_value_buffer[n];
}
uint16_t switch_high_pwm(uint8_t n){
		for(uint8_t i=0;i<9;i++){
			//小端转换
        	pwm_value_buffer[i]=(rx_buffer[4*i+7]<<8)|rx_buffer[4*i+6];
			if(pwm_value_buffer[i]>1900){
				pwm_value_buffer[i]=1900;
			}
			if(pwm_value_buffer[i]<1500){
				pwm_value_buffer[i]=1500;
			}
		}	
	  
	    
		return pwm_value_buffer[n];
}
//打开相应位置舵机
void servo_up(uint8_t servo_number){
	pwm_init();
	switch(servo_number){
		case 0: __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1,switch_high_pwm(servo_number));break;
	    case 1: __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2,switch_high_pwm(servo_number));break;
		case 2: __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3,switch_high_pwm(servo_number));break;
		case 3: __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1,switch_high_pwm(servo_number));break;
		case 4: __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2,switch_high_pwm(servo_number));break;
		case 5: __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3,switch_high_pwm(servo_number));break;
//		case 6: __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1,switch_pwm(value));break;
//		case 7: __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2,switch_pwm(value));break;
//		case 8: __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3,switch_pwm(value));break;
		default:break;
}
}
//关闭相应位置舵机
void servo_down(uint8_t servo_number){
		pwm_init();
		switch(servo_number){
		case 0: __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1,switch_low_pwm(servo_number));break;
	    case 1: __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2,switch_low_pwm(servo_number));break;
		case 2: __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_3,switch_low_pwm(servo_number));break;
		case 3: __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1,switch_low_pwm(servo_number));break;
		case 4: __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2,switch_low_pwm(servo_number));break;
		case 5: __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_3,switch_low_pwm(servo_number));break;
//		case 6: __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1,switch_pwm(value));break;
//		case 7: __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2,switch_pwm(value));break;
//		case 8: __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3,switch_pwm(value));break;
		default:break;
}
}


void process_control_bits(void)
{
  uint8_t control_low = rx_buffer[CONTROL_LOW_INDEX];  // 控制低字�?

  // 遍历�?6位（bit0~bit5�?
  for (uint16_t i = 0; i < 9; i++)
  {
    if (control_low & (1 << i))  // 第i位为1 打开舵机
    {
	  
      servo_up(i);
    }
	else
	  
	  servo_down(i);             // 第i位为0 关闭舵机
  }
 
}




void process_frame(void)
{
  if (rx_buffer[0] != FRAME_HEADER1 || rx_buffer[1] != FRAME_HEADER2)
  {
    uint8_t err[] = "header err\r\n";
    HAL_UART_Transmit(&huart3, err, sizeof(err)-1, 100);
    reset_receive();
    return;
  }
  uint8_t calc_sum = calculate_checksum();
  if (calc_sum != rx_buffer[CHECKSUM_INDEX])
  {
	  
    uint8_t err[] = "checksum err\r\n";
    HAL_UART_Transmit(&huart3, err, sizeof(err)-1, 100);
    reset_receive();
    return;
  }

  // 3. 处理控制位并输出
  process_control_bits();
  reset_receive();
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART3)
  {
    rx_count++;  // 每接�?1字节，计�?+1

    // 情况1：接收字节数超过41（异常长度）
    if (rx_count > FRAME_LENGTH)
    {
      uint8_t err[] = "len err: over 41\r\n";
      HAL_UART_Transmit(&huart3, err, sizeof(err)-1, 100);
      reset_receive();  // 清除异常数据，重新接�?
      return;
    }

    // 情况2：接收满41字节（正确长度）
    if (rx_count == FRAME_LENGTH)
    {
      process_frame();  // 处理完整�?
      return;
    }

    // 情况3：未接收�?5字节，继续接收下�?字节
    HAL_UART_Receive_IT(&huart3, &rx_buffer[rx_count], 1);
  }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */



